import styleSheet from "./getAdsElement.module.css";
export default function GetAdsElement({adDetails,adImage}){
    return (
        <div className={styleSheet.container}>
            
        </div>
    );
}