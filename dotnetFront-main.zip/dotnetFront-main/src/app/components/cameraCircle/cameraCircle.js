import styleSheet from "./cameraCircle.module.css"
export default function ProfileCircle(element){
    return 
    <div>
        <div>
            {element}
        </div>
    </div>;
}